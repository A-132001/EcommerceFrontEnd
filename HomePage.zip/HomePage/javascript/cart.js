// open and close card

var cart = document.querySelector('.cart');
function open_cart()
{
    cart.classList.add("active")
}
function close_cart()
{
    cart.classList.remove("active")
}